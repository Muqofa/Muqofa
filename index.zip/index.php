<?php
  header("Location: pages/layout/login.php");
?>