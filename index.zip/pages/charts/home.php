<?php
  $active_menu = "chartjs";
  include_once "../layout/header.php";
?>

<body class="hold-transition skin-blue sidebar-mini">
  <!-- Put Page-level css and javascript libraries here -->

  <!-- ChartJS -->
  <script src="../../plugins/chartjs/Chart.min.js"></script>

  <!-- ================================================ -->

  <div class="wrapper">

    <?php include_once "../layout/topmenu.php"; ?>
    <?php include_once "../layout/left-sidebar.php"; ?>
    

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <!-- <section class="content-header">
        <h1>
          Dashboard 
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Dashboard</li>
        </ol>
      </section> -->

      <!-- Main content -->
      <section class="content">

        <?php include_once("home/main_header.php") ?>
        
      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    
    <?php include_once "../layout/copyright.php"; ?>
    <?php include_once "../layout/right-sidebar.php"; ?>

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
  </div><!-- ./wrapper -->

<?php include_once "../layout/footer.php" ?>
<script src="home/script.js"></script>
<script>
/* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var areaChartCanvas = $("#areaChart").get(0).getContext("2d");
    // This will get the first returned node in the jQuery collection.
    var areaChart = new Chart(areaChartCanvas);
    <?php
    $tbl1 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah_harga) as jumlah 
                                    from vpembelian_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $db1 = '0';$db2 = '0';$db3 = '0';$db4 = '0';$db5 = '0';$db6 = '0';$db7 = '0';$db8 = '0';$db9 = '0';$db10 = '0';$db11 = '0';$db12 = '0';
    while($row = mysqli_fetch_array($tbl1))
    { 
        switch ($row["bulan"]) {
          case "1":
            $db1 = '' .$row["jumlah"]. '';
            break;
          case "2":
            $db2 = '' .$row["jumlah"]. '';
            break;
          case "3":
            $db3 = '' .$row["jumlah"]. '';
            break;
          case "4":
            $db4 = '' .$row["jumlah"]. '';
            break;
          case "5":
            $db5 = '' .$row["jumlah"]. '';
            break;
          case "6":
            $db6 = '' .$row["jumlah"]. '';
            break;
          case "7":
            $db7 = '' .$row["jumlah"]. '';
            break;
          case "8":
            $db8 = '' .$row["jumlah"]. '';
            break;
          case "9":
            $db9 = '' .$row["jumlah"]. '';
            break;
          case "10":
            $db10 = '' .$row["jumlah"]. '';
            break;
          case "11":
            $db11 = '' .$row["jumlah"]. '';
            break;
          case "12":
            $db12 = '' .$row["jumlah"]. '';
            break;
        }
    }
    $tbl2 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah_harga) as jumlah 
                                    from vpenjualan_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $dj1 = '0';$dj2 = '0';$dj3 = '0';$dj4 = '0';$dj5 = '0';$dj6 = '0';$dj7 = '0';$dj8 = '0';$dj9 = '0';$dj10 = '0';$dj11 = '0';$dj12 = '0';
    while($row = mysqli_fetch_array($tbl2))
    { 
        switch ($row["bulan"]) {
          case "1":
            $dj1 = '' .$row["jumlah"]. '';
            break;
          case "2":
            $dj2 = '' .$row["jumlah"]. '';
            break;
          case "3":
            $dj3 = '' .$row["jumlah"]. '';
            break;
          case "4":
            $dj4 = '' .$row["jumlah"]. '';
            break;
          case "5":
            $dj5 = '' .$row["jumlah"]. '';
            break;
          case "6":
            $dj6 = '' .$row["jumlah"]. '';
            break;
          case "7":
            $dj7 = '' .$row["jumlah"]. '';
            break;
          case "8":
            $dj8 = '' .$row["jumlah"]. '';
            break;
          case "9":
            $dj9 = '' .$row["jumlah"]. '';
            break;
          case "10":
            $dj10 = '' .$row["jumlah"]. '';
            break;
          case "11":
            $dj11 = '' .$row["jumlah"]. '';
            break;
          case "12":
            $dj12 = '' .$row["jumlah"]. '';
            break;
        }
    }
    ?>

    var areaChartData = {
        labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
      datasets: [
        {
          label: "Pembelian",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [
            <?php
                echo '' .$db1. ',' .$db2. ',' .$db3. ',' .$db4. ',' .$db5. ',' .$db6. ',' .$db7. ',' .$db8. ',' .$db9. ',' .$db10. ',' .$db11. ',' .$db12. '';  
            ?>
          ]
        },
        {
          label: "Penjualan",
          fillColor: "rgba(60,141,188,0.9)",
          strokeColor: "rgba(60,141,188,0.8)",
          pointColor: "#3b8bba",
          pointStrokeColor: "rgba(60,141,188,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(60,141,188,1)",
          data: [
            <?php
                echo '' .$dj1. ',' .$dj2. ',' .$dj3. ',' .$dj4. ',' .$dj5. ',' .$dj6. ',' .$dj7. ',' .$dj8. ',' .$dj9. ',' .$dj10. ',' .$dj11. ',' .$dj12. '';  
            ?>
          ]
        }
      ]
    };

    var areaChartOptions = {
      //Boolean - If we should show the scale at all
      showScale: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: false,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - Whether the line is curved between points
      bezierCurve: true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension: 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot: false,
      //Number - Radius of each point dot in pixels
      pointDotRadius: 4,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth: 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius: 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke: true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth: 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill: true,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].lineColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio: true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive: true
    };

    //Create the line chart
    areaChart.Line(areaChartData, areaChartOptions);

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas = $("#barChart").get(0).getContext("2d");
    var barChart = new Chart(barChartCanvas);
    <?php
    $tbl = mysqli_query($koneksi,"select nama_barang,sum(jumlah) as jumlah from vpenjualan_detail group by nama_barang order by sum(jumlah) desc limit 20");
    $labels = '';
    $datas = '';
    while($row = mysqli_fetch_array($tbl))
    { 
        if ($labels == ''){              
	        $labels .= '"' .$row["nama_barang"]. '"';	
            $datas .= '' .$row["jumlah"]. '';	
		}else{
            $labels .= ',"' .$row["nama_barang"]. '"';
            $datas .= ',' .$row["jumlah"]. '';	
		}
    }
    ?>
    var barChartData = {
        labels: [
            <?php
                echo  $labels;  
            ?>
        ],
      datasets: [
        {
          label: "Nama Barang",
          fillColor: "rgba(60,141,188,0.9)",
          strokeColor: "rgba(60,141,188,0.8)",
          pointColor: "#3b8bba",
          pointStrokeColor: "rgba(60,141,188,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(60,141,188,1)",
          data: [
            <?php
                echo  $datas;  
            ?>
          ]
        }
      ]
    };

    barChartData.datasets[0].fillColor = "#00a65a";
    barChartData.datasets[0].strokeColor = "#00a65a";
    barChartData.datasets[0].pointColor = "#00a65a";
    var barChartOptions = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - If there is a stroke on each bar
      barShowStroke: true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth: 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing: 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing: 1,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to make the chart responsive
      responsive: true,
      maintainAspectRatio: true
    };

    barChartOptions.datasetFill = false;
    barChart.Bar(barChartData, barChartOptions);

</script>