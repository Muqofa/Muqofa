<?php
  $active_menu = "chartjs";
  include_once "../layout/header.php";
?>

<body class="hold-transition skin-blue sidebar-mini">
  <!-- Put Page-level css and javascript libraries here -->

  <!-- ChartJS -->
  <script src="../../plugins/chartjs/BarChart_files/Chart.js"></script>
  <script src="../../plugins/chartjs/BarChart_files/utils.js"></script>

  <!-- ================================================ -->

  <div class="wrapper">

    <?php include_once "../layout/topmenu.php"; ?>
    <?php include_once "../layout/left-sidebar.php"; ?>
    

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Main content -->
      <section class="content">
		<?php
    $tbl1 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah_harga) as jumlah 
                                    from vpembelian_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $db1 = '0';$db2 = '0';$db3 = '0';$db4 = '0';$db5 = '0';$db6 = '0';$db7 = '0';$db8 = '0';$db9 = '0';$db10 = '0';$db11 = '0';$db12 = '0';$dbtotal = 0;
    $dl1 = 0;$dl2 = 0;$dl3 = 0;$dl4 = 0;$dl5 = 0;$dl6 = 0;$dl7 = 0;$dl8 = 0;$dl9 = 0;$dl10 = 0;$dl11 = 0;$dl12 = 0;$dltotal = 0;
    while($row = mysqli_fetch_array($tbl1))
    { 
        switch ($row["bulan"]) {
          case "1":
            $db1 = '' .$row["jumlah"]. '';
            $dl1 = $dl1-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "2":
            $db2 = '' .$row["jumlah"]. '';
            $dl2 = $dl2-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "3":
            $db3 = '' .$row["jumlah"]. '';
            $dl3 = $dl3-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "4":
            $db4 = '' .$row["jumlah"]. '';
            $dl4 = $dl4-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "5":
            $db5 = '' .$row["jumlah"]. '';
            $dl5 = $dl5-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "6":
            $db6 = '' .$row["jumlah"]. '';
            $dl6 = $dl6-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "7":
            $db7 = '' .$row["jumlah"]. '';
            $dl7 = $dl7-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "8":
            $db8 = '' .$row["jumlah"]. '';
            $dl8 = $dl8-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "9":
            $db9 = '' .$row["jumlah"]. '';
            $dl9 = $dl9-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "10":
            $db10 = '' .$row["jumlah"]. '';
            $dl10 = $dl10-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "11":
            $db11 = '' .$row["jumlah"]. '';
            $dl11 = $dl11-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
          case "12":
            $db12 = '' .$row["jumlah"]. '';
            $dl12 = $dl12-$row["jumlah"];
            $dltotal = $dltotal-$row["jumlah"];
            $dbtotal = $dbtotal+$row["jumlah"];
            break;
        }
    }
    $tbl2 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah_harga) as jumlah,sum(jumlah_laba) as jumlah_laba 
                                    from vpenjualan_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $dj1 = '0';$dj2 = '0';$dj3 = '0';$dj4 = '0';$dj5 = '0';$dj6 = '0';$dj7 = '0';$dj8 = '0';$dj9 = '0';$dj10 = '0';$dj11 = '0';$dj12 = '0';$djtotal = 0;
    $dl1 = 0;$dl2 = 0;$dl3 = 0;$dl4 = 0;$dl5 = 0;$dl6 = 0;$dl7 = 0;$dl8 = 0;$dl9 = 0;$dl10 = 0;$dl11 = 0;$dl12 = 0;$dltotal = 0;
    
    while($row = mysqli_fetch_array($tbl2))
    { 
        switch ($row["bulan"]) {
          case "1":
            $dj1 = '' .$row["jumlah"]. '';
            $dl1 = $dl1+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];

            $dl1 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "2":
            $dj2 = '' .$row["jumlah"]. '';
            $dl2 = $dl2+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];

            $dl2 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "3":
            $dj3 = '' .$row["jumlah"]. '';
            $dl3= $dl3+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl3 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "4":
            $dj4 = '' .$row["jumlah"]. '';
            $dl4 = $dl4+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl4 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "5":
            $dj5 = '' .$row["jumlah"]. '';
            $dl5 = $dl5+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl5 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "6":
            $dj6 = '' .$row["jumlah"]. '';
            $dl6 = $dl6+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl6 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "7":
            $dj7 = '' .$row["jumlah"]. '';
            $dl7 = $dl7+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl7 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "8":
            $dj8 = '' .$row["jumlah"]. '';
            $dl8 = $dl8+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl8 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "9":
            $dj9 = '' .$row["jumlah"]. '';
            $dl9 = $dl9+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl9 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "10":
            $dj10 = '' .$row["jumlah"]. '';
            $dl10 = $dl10+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl10 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "11":
            $dj11 = '' .$row["jumlah"]. '';
            $dl11 = $dl11+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl11 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
          case "12":
            $dj12 = '' .$row["jumlah"]. '';
            $dl1 = $dl12+$row["jumlah"];
            $djtotal = $djtotal+$row["jumlah"];
            
            $dl12 = '' .$row["jumlah_laba"]. '';
            $dltotal = $dltotal+$row["jumlah_laba"];
            
            break;
        }
    }

    $tbl = mysqli_query($koneksi,"select nama_barang,sum(jumlah) as jumlah from vpenjualan_detail group by nama_barang order by sum(jumlah) desc limit 20");
    $labels = '';
    $datas = '';
    while($row = mysqli_fetch_array($tbl))
    { 
        if ($labels == ''){              
	        $labels .= '"' .$row["nama_barang"]. '"';	
            $datas .= '' .$row["jumlah"]. '';	
		}else{
            $labels .= ',"' .$row["nama_barang"]. '"';
            $datas .= ',' .$row["jumlah"]. '';	
		}
    }
    ?>
    <div class="row">
  <div class="col-md-12">
    <!-- AREA CHART -->
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Penjualan & Laba Rugi</h3>

        <div class="box-tools pull-right">
        
        </div>
      </div>
      <div class="box-body">
        <div class="chart">
          <canvas id="areaChart" style="height:250px"></canvas>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

    <!-- /.box -->

  </div>
  <!-- /.col (LEFT) -->
  <div class="col-md-12">
    
    <!-- BAR CHART -->
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Barang Terlaris</h3>

        <div class="box-tools pull-right">
        </div>
      </div>
      <div class="box-body">
        <div class="chart">
          <canvas id="barChart" style="height:230px"></canvas>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

  </div>
  <!-- /.col (RIGHT) -->
  <!-- /.col (LEFT) -->
  <div class="col-md-12">
    
    <!-- BAR CHART -->
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Laba Rugi</h3>

        <div class="box-tools pull-right">
        </div>
      </div>
      <div class="box-body">

        <table class="table table-bordered">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Item</th>
                  <th style="width: 40px">Januari</th>
                  <th style="width: 40px">Februari</th>
                  <th style="width: 40px">Maret</th>
                  <th style="width: 40px">April</th>
                  <th style="width: 40px">Mei</th>
                  <th style="width: 40px">Juni</th>
                  <th style="width: 40px">Juli</th>
                  <th style="width: 40px">Agustus</th>
                  <th style="width: 40px">September</th>
                  <th style="width: 40px">Oktober</th>
                  <th style="width: 40px">November</th>
                  <th style="width: 40px">Desember</th>
                  <th style="width: 40px">Total</th>
                </tr>
                
                <tr>
                  <td style="width: 10px">1</td>
                  <td>Penjualan</td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj1); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj2); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj3); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj4); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj5); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj6); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj7); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj8); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj9); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj10); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj11); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dj12); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($djtotal); ?></td>
                </tr>
                <tr>
                  <td style="width: 10px">2</td>
                  <td>Laba Rugi</td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl1); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl2); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl3); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl4); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl5); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl6); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl7); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl8); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl9); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl10); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl11); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dl12); ?></td>
                  <td style="width: 40px;text-align:right"><?php echo  number_format($dltotal); ?></td>
                </tr>
              </table>
        
        <div class="chart" style="display:none">
          <canvas id="canvasLaba" style="height:230px"></canvas>
        </div>
        
      </div>
      <!-- /.box-body
    </div>
    <!-- /.box -->

  </div>
  <!-- /.col (RIGHT) -->
</div>
<!-- /.row -->
        <?php include_once("homePimpinan/main_header.php") ?>
        
      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    
    <?php include_once "../layout/copyright.php"; ?>
    <?php include_once "../layout/right-sidebar.php"; ?>

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
  </div><!-- ./wrapper -->

<?php include_once "../layout/footer.php" ?>
<script>
    
/* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    var MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
	var color = Chart.helpers.color;
	var barChartDataLaba = {
	labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
	datasets: [{
			label: 'LabaRugi',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
				<?php
                    echo '' .$dl1. ',' .$dl2. ',' .$dl3. ',' .$dl4. ',' .$dl5. ',' .$dl6. ',' .$dl7. ',' .$dl8. ',' .$dl9. ',' .$dl10. ',' .$dl11. ',' .$dl12. '';  
                 ?>
			]
		}]

	};

    var barChartData = {
	labels: [
        <?php
              echo  $labels;  
        ?>
    ],
	datasets: [{
			label: 'Barang Terlaris',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
                <?php
                    echo  $datas;  
                ?>
			]
		}]

	};

    var areaChartData = {
	labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
	datasets: [{
			label: 'Laba Rugi',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
                <?php
                    echo '' .$dl1. ',' .$dl2. ',' .$dl3. ',' .$dl4. ',' .$dl5. ',' .$dl6. ',' .$dl7. ',' .$dl8. ',' .$dl9. ',' .$dl10. ',' .$dl11. ',' .$dl12. '';  
                ?>
			]
		},
        {
			label: 'Penjualan',
			backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
			borderColor: window.chartColors.red,
			borderWidth: 1,
			data: [
                <?php
                 echo '' .$dj1. ',' .$dj2. ',' .$dj3. ',' .$dj4. ',' .$dj5. ',' .$dj6. ',' .$dj7. ',' .$dj8. ',' .$dj9. ',' .$dj10. ',' .$dj11. ',' .$dj12. '';  
                ?>
			]
		}
      ]

	};

	window.onload = function() {
		var ctx = document.getElementById('canvasLaba').getContext('2d');
		window.myBar = new Chart(ctx, {
			type: 'bar',
			data: barChartDataLaba,
			options: {
				responsive: true,
				legend: {
					position: 'top',
                    display: false
				},
				title: {
					display: false,
					text: 'Laba Atau Rugi'
				}
			}
		});

		var ctx2 = document.getElementById('barChart').getContext('2d');
		window.myBar2 = new Chart(ctx2, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
                    display: false
				},
				title: {
					display: false,
					text: 'Barang Terlaris'
				},
                scales: { 
                    yAxes: [{ 
                                ticks: { 
                                        beginAtZero: true 
                                        }
                            }]
                    }                        
			}
		});
        
		var ctx3 = document.getElementById('areaChart').getContext('2d');
		window.myBar3 = new Chart(ctx3, {
			type: 'bar',
			data: areaChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
                    display: true
				},
				title: {
					display: false,
					text: ''
				},
                scales: { 
                    yAxes: [{ 
                                ticks: { 
                                        beginAtZero: true 
                                        }
                            }]
                    }                        
			}
		});
	};


</script>