<?php
  $active_menu = "chartjs";
  include_once "../layout/header.php";
?>

<body class="hold-transition skin-blue sidebar-mini">
  <!-- Put Page-level css and javascript libraries here -->

  <!-- ChartJS -->
  <script src="../../plugins/chartjs/BarChart_files/Chart.js"></script>
  <script src="../../plugins/chartjs/BarChart_files/utils.js"></script>

  <!-- ================================================ -->

  <div class="wrapper">

    <?php include_once "../layout/topmenu.php"; ?>
    <?php include_once "../layout/left-sidebar.php"; ?>
    

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <!-- <section class="content-header">
        <h1>
          Dashboard 
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Dashboard</li>
        </ol>
      </section> -->

      <!-- Main content -->
      <section class="content">

        <?php include_once("homePengelola/main_header.php") ?>
        
      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    
    <?php include_once "../layout/copyright.php"; ?>
    <?php include_once "../layout/right-sidebar.php"; ?>

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
  </div><!-- ./wrapper -->

<?php include_once "../layout/footer.php" ?>
<script>
    <?php
    $tbl1 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah) as jumlah 
                                    from vpembelian_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $db1 = '0';$db2 = '0';$db3 = '0';$db4 = '0';$db5 = '0';$db6 = '0';$db7 = '0';$db8 = '0';$db9 = '0';$db10 = '0';$db11 = '0';$db12 = '0';
    $dl1 = 0;$dl2 = 0;$dl3 = 0;$dl4 = 0;$dl5 = 0;$dl6 = 0;$dl7 = 0;$dl8 = 0;$dl9 = 0;$dl10 = 0;$dl11 = 0;$dl12 = 0;
    while($row = mysqli_fetch_array($tbl1))
    { 
        switch ($row["bulan"]) {
          case "1":
            $db1 = '' .$row["jumlah"]. '';
            $dl1 = $dl1-$row["jumlah"];
            break;
          case "2":
            $db2 = '' .$row["jumlah"]. '';
            $dl2 = $dl2-$row["jumlah"];
            break;
          case "3":
            $db3 = '' .$row["jumlah"]. '';
            $dl3 = $dl3-$row["jumlah"];
            break;
          case "4":
            $db4 = '' .$row["jumlah"]. '';
            $dl4 = $dl4-$row["jumlah"];
            break;
          case "5":
            $db5 = '' .$row["jumlah"]. '';
            $dl5 = $dl5-$row["jumlah"];
            break;
          case "6":
            $db6 = '' .$row["jumlah"]. '';
            $dl6 = $dl6-$row["jumlah"];
            break;
          case "7":
            $db7 = '' .$row["jumlah"]. '';
            $dl7 = $dl7-$row["jumlah"];
            break;
          case "8":
            $db8 = '' .$row["jumlah"]. '';
            $dl8 = $dl8-$row["jumlah"];
            break;
          case "9":
            $db9 = '' .$row["jumlah"]. '';
            $dl9 = $dl9-$row["jumlah"];
            break;
          case "10":
            $db10 = '' .$row["jumlah"]. '';
            $dl10 = $dl10-$row["jumlah"];
            break;
          case "11":
            $db11 = '' .$row["jumlah"]. '';
            $dl11 = $dl11-$row["jumlah"];
            break;
          case "12":
            $db12 = '' .$row["jumlah"]. '';
            $dl12 = $dl12-$row["jumlah"];
            break;
        }
    }
    $tbl2 = mysqli_query($koneksi,"select month(tanggal_posting) as bulan,sum(jumlah) as jumlah 
                                    from vpenjualan_detail 
                                    where year(tanggal_posting)=YEAR(CURDATE()) 
                                    group by month(tanggal_posting) 
                                    ");
    $dj1 = '0';$dj2 = '0';$dj3 = '0';$dj4 = '0';$dj5 = '0';$dj6 = '0';$dj7 = '0';$dj8 = '0';$dj9 = '0';$dj10 = '0';$dj11 = '0';$dj12 = '0';
    while($row = mysqli_fetch_array($tbl2))
    { 
        switch ($row["bulan"]) {
          case "1":
            $dj1 = '' .$row["jumlah"]. '';
            $dl1 = $dl1+$row["jumlah"];
            break;
          case "2":
            $dj2 = '' .$row["jumlah"]. '';
            $dl2 = $dl2+$row["jumlah"];
            break;
          case "3":
            $dj3 = '' .$row["jumlah"]. '';
            $dl3= $dl3+$row["jumlah"];
            break;
          case "4":
            $dj4 = '' .$row["jumlah"]. '';
            $dl4 = $dl4+$row["jumlah"];
            break;
          case "5":
            $dj5 = '' .$row["jumlah"]. '';
            $dl5 = $dl5+$row["jumlah"];
            break;
          case "6":
            $dj6 = '' .$row["jumlah"]. '';
            $dl6 = $dl6+$row["jumlah"];
            break;
          case "7":
            $dj7 = '' .$row["jumlah"]. '';
            $dl7 = $dl7+$row["jumlah"];
            break;
          case "8":
            $dj8 = '' .$row["jumlah"]. '';
            $dl8 = $dl8+$row["jumlah"];
            break;
          case "9":
            $dj9 = '' .$row["jumlah"]. '';
            $dl9 = $dl9+$row["jumlah"];
            break;
          case "10":
            $dj10 = '' .$row["jumlah"]. '';
            $dl10 = $dl10+$row["jumlah"];
            break;
          case "11":
            $dj11 = '' .$row["jumlah"]. '';
            $dl11 = $dl11+$row["jumlah"];
            break;
          case "12":
            $dj12 = '' .$row["jumlah"]. '';
            $dl1 = $dl12+$row["jumlah"];
            break;
        }
    }

    $tbl = mysqli_query($koneksi,"select nama_barang,sum(jumlah) as jumlah from vpenjualan_detail group by nama_barang order by sum(jumlah) desc limit 20");
    $labels = '';
    $datas = '';
    while($row = mysqli_fetch_array($tbl))
    { 
        if ($labels == ''){              
	        $labels .= '"' .$row["nama_barang"]. '"';	
            $datas .= '' .$row["jumlah"]. '';	
		}else{
            $labels .= ',"' .$row["nama_barang"]. '"';
            $datas .= ',' .$row["jumlah"]. '';	
		}
    }
    ?>
/* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    var MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
	var color = Chart.helpers.color;
	var barChartDataLaba = {
	labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
	datasets: [{
			label: 'LabaRugi',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
				<?php
                    echo '' .$dl1. ',' .$dl2. ',' .$dl3. ',' .$dl4. ',' .$dl5. ',' .$dl6. ',' .$dl7. ',' .$dl8. ',' .$dl9. ',' .$dl10. ',' .$dl11. ',' .$dl12. '';  
                 ?>
			]
		}]

	};

    var barChartData = {
	labels: [
        <?php
              echo  $labels;  
        ?>
    ],
	datasets: [{
			label: 'Barang Terlaris',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
                <?php
                    echo  $datas;  
                ?>
			]
		}]

	};

    var areaChartData = {
	labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
	datasets: [{
			label: 'Pembelian',
			backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
			borderColor: window.chartColors.blue,
			borderWidth: 1,
			data: [
                <?php
                    echo '' .$db1. ',' .$db2. ',' .$db3. ',' .$db4. ',' .$db5. ',' .$db6. ',' .$db7. ',' .$db8. ',' .$db9. ',' .$db10. ',' .$db11. ',' .$db12. '';  
                ?>
			]
		},
        {
			label: 'Penjualan',
			backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
			borderColor: window.chartColors.red,
			borderWidth: 1,
			data: [
                <?php
                 echo '' .$dj1. ',' .$dj2. ',' .$dj3. ',' .$dj4. ',' .$dj5. ',' .$dj6. ',' .$dj7. ',' .$dj8. ',' .$dj9. ',' .$dj10. ',' .$dj11. ',' .$dj12. '';  
                ?>
			]
		}
      ]

	};

	window.onload = function() {

		var ctx2 = document.getElementById('barChart').getContext('2d');
		window.myBar2 = new Chart(ctx2, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
                    display: false
				},
				title: {
					display: false,
					text: 'Barang Terlaris'
				},
                scales: { 
                    yAxes: [{ 
                                ticks: { 
                                        beginAtZero: true 
                                        }
                            }]
                    }                        
			}
		});
        
		var ctx3 = document.getElementById('areaChart').getContext('2d');
		window.myBar3 = new Chart(ctx3, {
			type: 'line',
			data: areaChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
                    display: false
				},
				title: {
					display: false,
					text: ''
				},
                scales: { 
                    yAxes: [{ 
                                ticks: { 
                                        beginAtZero: true 
                                        }
                            }]
                    }                        
			}
		});
	};


</script>