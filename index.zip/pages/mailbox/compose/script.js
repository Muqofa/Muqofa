$(function () {
    //Add text editor
    $("#compose-textarea").wysihtml5();
  });