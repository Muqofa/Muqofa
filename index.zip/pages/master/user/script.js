$(function () {
  $('#example').DataTable( {
    dom: 'Bfrtip',
        buttons: [
            'excel', 'pdf'
        ]
    } );

  });