<?php
include '../../layout/functions.php';

$username = $_GET['username'];
if ($username == "admin") {
    //admin tidk boleh dihapus;
} else {
    mysqli_query($koneksi,"DELETE FROM tuser WHERE username='$username'");
    
}
 
header("location:../../master/user.php");

?>