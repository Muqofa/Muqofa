<?php 
include '../../layout/functions.php';

$username = $_POST['username'];
$nama = $_POST['nama'];
$password = $_POST['password'];
$role = $_POST['role'];
$password = md5($password);

mysqli_query($koneksi,"INSERT INTO tuser VALUES('$username','$password','$role','$nama')");
 
header("location:../../master/user.php");

?>