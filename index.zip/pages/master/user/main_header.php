<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      User
        <small>master</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="row">
        <div class="col-md-4">
          <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Tambah User</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form role="form" action="user/input-aksi.php" method="post">
                <div class="box-body">
                  
                <div class="form-group">
                  <label for="username">User name</label>
                  <input type="text" class="form-control" name="username" placeholder="Username">
                </div>
                  
                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" name="password" placeholder="Password">
                </div>
                  
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" name="nama" placeholder="Nama">
                </div>

                <!-- form group -->
                  <div class="form-group">
                    <label>Role</label>
                    <select class="form-control select2" style="width: 100%;" name="role">
                      <?php
                          include '../layout/functions.php';
                          $tbl = mysqli_query($koneksi,"select * from trole");
                          while($row = mysqli_fetch_array($tbl))
                          {
                              echo "<option value=".$row['role'].">".$row['role']."</option>";
                          }
                      ?>                  
                    </select>
                  </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
              </form>
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
        <div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">User List</h3>
              <div class="box-tools">
                 
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <table id="example" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th>User Name</th>
                      <th>Password</th>
                      <th>Nama</th>
                      <th>Role</th>
                      <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        include '../layout/functions.php';
                        $tbl = mysqli_query($koneksi,"select * from tuser");
                        while($row = mysqli_fetch_array($tbl))
                        {
                            echo "<tr>
                            <td>".$row['username']."</td>
                            <td>".$row['password']."</td>
                            <td>".$row['nama']."</td>
                            <td>".$row['role']."</td>
                            <td>
                                <a href='user/delete.php?username=$row[username]'>Delete</a>
                            </td>
                        </tr>";
                        }
                    ?>
                    </tbody>
                  </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->