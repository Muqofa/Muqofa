<?php 
include '../../layout/functions.php';

$kode_supplier = $_POST['kode_supplier'];

//echo "".$kode_supplier."";

$nama_supplier = $_POST['nama_supplier'];
$alamat = $_POST['alamat'];
$telp = $_POST['telp'];

session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

mysqli_query($koneksi,"UPDATE tsupplier 
                    SET nama_supplier = '$nama_supplier', 
                    alamat='$alamat', 
                    telp='$telp' , 
                    update_date='$update_date' , 
                    update_by='$update_by' 
                    WHERE kode_supplier='$kode_supplier';");
 
header("location:../../master/supplier.php");
?>