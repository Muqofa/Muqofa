$(function () {
  $('#example').DataTable( {
    dom: 'Bfrtip',
        buttons: [
            {
                text: 'Tambah',
                action: function ( e, dt, node, config ) {
                    window.location = '../master/tambah_supplier.php';
                    //alert( 'Menuju form tambah' );
                }
            }
            , 'excel', 'pdf'
        ]
    } );

  });