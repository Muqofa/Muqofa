<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Supplier
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Supplier</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tambah Supplier</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="supplier/edit-aksi.php" method="post">
            <?php
                $kode_supplier = $_GET['kode_supplier'];
                $tbl = mysqli_query($koneksi,"select * from tsupplier where kode_supplier = '$kode_supplier'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        $nama_supplier = $row['nama_supplier'];
                        $alamat = $row['alamat'];
                        $telp = $row['telp'];
                        break 1;
                    }
            echo "
              <div class='box-body'>
                <div class='form-group'>
                  <label>Kode Supplier</label>                  
                    <input type='number' disabled  class='form-control' 
                        name='kode_supplier' value='".$kode_supplier."'> 
                     
                    <input type='hidden' class='form-control' 
                        name='kode_supplier' value='".$kode_supplier."' id='kode_supplier'>
                </div>
                
                <div class='form-group'>
                  <label>Nama Supplier</label>
                  <input type='text' class='form-control' name='nama_supplier' id='nama_supplier' value='".$nama_supplier."'>
                </div>
                
                <div class='form-group'>
                  <label>Alamat</label>
                  <input type='text' name='alamat' class='form-control' value='".$alamat."'>
                </div>
                
                <div class='form-group'>
                  <label>Telp</label>
                  <input type='text' name='telp' class='form-control' value='".$telp."'>
                </div>
                
              </div>
              <!-- /.box-body -->";
              ?>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
                <button type="button" class="btn btn-default" onclick="window.location = 'supplier.php';">Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->