<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Pelanggan
        <small>Master</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Pelanggan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Pelanggan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Kode Pelanggan</th>
                  <th>Nama Pelanggan</th>
                  <th>Alamat</th>
                  <th>Telp</th>
                  <th>Update Date</th>
                  <th>Update By</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    $tbl = mysqli_query($koneksi,"select * from tpelanggan");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        echo "<tr>
                        <td>".$row['kode_pelanggan']."</td>
                        <td>".$row['nama_pelanggan']."</td>
                        <td>".$row['alamat']."</td>
                        <td>".$row['telp']."</td>
                        <td>".$row['update_date']."</td>
                        <td>".$row['update_by']."</td>
                        <td>
                            <a href='tambah_pelanggan/delete.php?kode_pelanggan=$row[kode_pelanggan]'>Delete</a>
                            |
                            <a href='edit_pelanggan.php?kode_pelanggan=$row[kode_pelanggan]'>Edit</a>
                        </td>
                    </tr>";
                    }
                ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->