<?php 
include '../../layout/functions.php';

$kode_pelanggan = $_POST['kode_pelanggan'];

//echo "".$kode_pelanggan."";

$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$telp = $_POST['telp'];
$update_date = date("Y-m-d h:i:s");
session_start();
$update_by = $_SESSION['userid'];
mysqli_query($koneksi,"UPDATE tpelanggan 
                    SET nama_pelanggan = '$nama_pelanggan', 
                    alamat='$alamat', 
                    telp='$telp' , 
                    update_date='$update_date' , 
                    update_by='$update_by' 
                    WHERE kode_pelanggan='$kode_pelanggan';");
 
header("location:../../master/pelanggan.php");


?>