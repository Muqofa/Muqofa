<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Pelanggan
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Pelanggan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tambah Pelanggan</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="pelanggan/edit-aksi.php" method="post">
            <?php
                $kode_pelanggan = $_GET['kode_pelanggan'];
                $tbl = mysqli_query($koneksi,"select * from tpelanggan where kode_pelanggan = '$kode_pelanggan'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        $nama_pelanggan = $row['nama_pelanggan'];
                        $alamat = $row['alamat'];
                        $telp = $row['telp'];
                        break 1;
                    }
            echo "
              <div class='box-body'>
                <div class='form-group'>
                  <label>Kode pelanggan</label>                  
                    <input type='number' disabled  class='form-control' 
                        name='kode_pelanggan' value='".$kode_pelanggan."'> 
                     
                    <input type='hidden' class='form-control' 
                        name='kode_pelanggan' value='".$kode_pelanggan."' id='kode_pelanggan'>
                </div>
                
                <div class='form-group'>
                  <label>Nama Pelanggan</label>
                  <input type='text' class='form-control' name='nama_pelanggan' id='nama_pelanggan' value='".$nama_pelanggan."'>
                </div>
                
                <div class='form-group'>
                  <label>Alamat</label>
                  <input type='text' name='alamat' class='form-control' value='".$alamat."'>
                </div>
                
                <div class='form-group'>
                  <label>Telp</label>
                  <input type='text' name='telp' class='form-control' value='".$telp."'>
                </div>
                
              </div>
              <!-- /.box-body -->";
              ?>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
                <button type="button" class="btn btn-default" onclick="window.location = 'pelanggan.php';">Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->