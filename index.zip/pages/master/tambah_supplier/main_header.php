<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Tambah Supplier
        <small>master</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Tambah Supplier</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tambah Supplier</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="tambah_supplier/input-aksi.php" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Kode</label>
                  <input type="number" disabled  class="form-control" id="exampleInputNumbr" placeholder="0" value="0">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Nama supplier</label>
                  <input type="text" class="form-control" name="nama_supplier" id="exampleInputText" placeholder="Nama supplier">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Alamat</label>
                  <input type="text" class="form-control" name="alamat" id="exampleInputText" placeholder="Alamat">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Telp</label>
                  <input type="text" class="form-control" name="telp" id="exampleInputText" placeholder="Telp">
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
                <button type="button" class="btn btn-default" onclick="window.location = 'supplier.php';">Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->