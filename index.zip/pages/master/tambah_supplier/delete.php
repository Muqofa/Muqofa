<?php
include '../../layout/functions.php';

$kode_supplier = $_GET['kode_supplier'];

mysqli_query($koneksi,"DELETE FROM tsupplier WHERE kode_supplier='$kode_supplier'");
 
header("location:../../master/supplier.php");

?>