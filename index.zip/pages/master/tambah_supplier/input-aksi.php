<?php 
include '../../layout/functions.php';

$nama_supplier = $_POST['nama_supplier'];
$alamat = $_POST['alamat'];
$telp = $_POST['telp'];

session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

mysqli_query($koneksi,"INSERT INTO tsupplier VALUES(0,'$nama_supplier','$alamat','$telp','$update_date','$update_by')");
 
header("location:../../master/supplier.php");
?>