<?php
include '../../layout/functions.php';

$kode_pelanggan = $_GET['kode_pelanggan'];

mysqli_query($koneksi,"DELETE FROM tpelanggan WHERE kode_pelanggan='$kode_pelanggan'");
 
header("location:../../master/pelanggan.php");

?>