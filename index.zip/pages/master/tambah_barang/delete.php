<?php
include '../../layout/functions.php';

$kode_barang = $_GET['kode_barang'];

mysqli_query($koneksi,"DELETE FROM tdata_barang WHERE kode_barang='$kode_barang'");
 
header("location:../../master/data_barang.php");

?>