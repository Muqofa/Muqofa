<?php 
include '../../layout/functions.php';

$nama_barang = $_POST['nama_barang'];
$harga_beli = $_POST['harga_beli'];
$harga_jual = $_POST['harga_jual'];

session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

mysqli_query($koneksi,"INSERT INTO tdata_barang VALUES(0,'$nama_barang','$harga_beli','$harga_jual','$update_date','$update_by')");
 
header("location:../../master/data_barang.php");
?>