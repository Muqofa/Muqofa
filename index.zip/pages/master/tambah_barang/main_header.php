<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Tambah Barang
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Tambah Barang</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tambah Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="tambah_barang/input-aksi.php" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Kode Barang</label>
                  <input type="number" disabled  class="form-control" id="exampleInputNumbr" placeholder="0" value="0">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputPassword1">Nama Barang</label>
                  <input type="text" class="form-control" name="nama_barang" id="exampleInputText" placeholder="Nama Barang">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Harga Beli</label>
                  <input type="number" name="harga_beli" class="form-control" placeholder="0" value="0">
                </div>
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Harga Jual</label>
                  <input type="number" name="harga_jual" class="form-control" placeholder="0" value="0">
                </div>
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
                <button type="button" class="btn btn-default" onclick="window.location = 'data_barang.php';">Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->