<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Barang
        <small>Master</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Barang</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Barang</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Kode Barang</th>
                  <th>Nama Barang</th>
                  <th align="right">Harga Beli</th>
                  <th align="right">Harga Jual</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    $tbl = mysqli_query($koneksi,"select * from tdata_barang");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        echo "<tr>
                        <td>".$row['kode_barang']."</td>
                        <td>".$row['nama_barang']."</td>
                        <td align='right'>".number_format($row['harga_beli'])."</td>
                        <td align='right'>".number_format($row['harga_jual'])."</td>
                        <td>
                            <a href='tambah_barang/delete.php?kode_barang=$row[kode_barang]'>Delete</a> 
                            |
                            <a href='edit_barang.php?kode_barang=$row[kode_barang]'>Edit</a>
                        </td>
                    </tr>";
                    }
                ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->