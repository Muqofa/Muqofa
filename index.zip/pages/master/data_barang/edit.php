<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Barang
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Edit Barang</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Form Tambah Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="data_barang/edit-aksi.php" method="post">
            <?php
                $kode_barang = $_GET['kode_barang'];
                $tbl = mysqli_query($koneksi,"select * from tdata_barang where kode_barang = '$kode_barang'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        $nama_barang = $row['nama_barang'];
                        $harga_beli = $row['harga_beli'];
                        $harga_jual = $row['harga_jual'];
                        break 1;
                    }
            echo "
              <div class='box-body'>
                <div class='form-group'>
                  <label>Kode Barang</label>                  
                    <input type='number' disabled  class='form-control' 
                        name='kode_barang' value='".$kode_barang."'> 
                     
                    <input type='hidden' class='form-control' 
                        name='kode_barang' value='".$kode_barang."' id='kode_barang'>
                </div>
                
                <div class='form-group'>
                  <label>Nama Barang</label>
                  <input type='text' class='form-control' name='nama_barang' id='nama_barang' value='".$nama_barang."'>
                </div>
                
                <div class='form-group'>
                  <label>Harga Beli</label>
                  <input type='number' name='harga_beli' class='form-control' value='".$harga_beli."'>
                </div>
                
                <div class='form-group'>
                  <label>Harga Jual</label>
                  <input type='number' name='harga_jual' class='form-control' value='".$harga_jual."'>
                </div>
                
              </div>
              <!-- /.box-body -->";
              ?>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
                <button type="button" class="btn btn-default" onclick="window.location = 'data_barang.php';">Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->