<?php 
include '../../layout/functions.php';

$kode_barang = $_POST['kode_barang'];

//echo "".$kode_barang."";

$nama_barang = $_POST['nama_barang'];
$harga_beli = $_POST['harga_beli'];
$harga_jual = $_POST['harga_jual'];

session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

mysqli_query($koneksi,"UPDATE tdata_barang 
                    SET nama_barang = '$nama_barang', 
                    harga_beli='$harga_beli', 
                    harga_jual='$harga_jual', 
                    tanggal_update='$update_date', 
                    update_by='$update_by'  
                    WHERE kode_barang='$kode_barang';");
 
header("location:../../master/data_barang.php");
?>