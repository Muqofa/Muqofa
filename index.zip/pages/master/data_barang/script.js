$(function () {
  $('#example').DataTable( {
    dom: 'Bfrtip',
        buttons: [
            {
                text: 'Tambah',
                action: function ( e, dt, node, config ) {
                    window.location = '../master/tambah_barang.php';
                    //alert( 'Menuju form tambah' );
                }
            }
            //,'copy', 'csv', 'excel', 'pdf', 'print'
            ,'excel','pdf'
        ]
    } );

  });