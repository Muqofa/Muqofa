<?php

require_once __DIR__ . '../../../plugins/mpdf/vendor/autoload.php';
include '../layout/functions.php';
$dari_tanggal = $_GET['dari_tanggal'];
$sampai_tanggal = $_GET['sampai_tanggal'];
$html = '

<html>
<head>
<style>
body {font-family: sans-serif;
	font-size: 10pt;
}
p {	margin: 0pt; }
table.items {
	border: 0.1mm solid #000000;
}
td { vertical-align: top; }
.items td {
	border-left: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
table thead td { background-color: #EEEEEE;
	text-align: center;
	border: 0.1mm solid #000000;
	font-variant: small-caps;
}
.items td.blanktotal {
	background-color: #EEEEEE;
	border: 0.1mm solid #000000;
	background-color: #FFFFFF;
	border: 0mm none #000000;
	border-top: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
.items td.totals {
	text-align: right;
	border: 0.1mm solid #000000;
}
.items td.cost {
	text-align: "." center;
}
</style>
</head>
<body>

<!--mpdf
<htmlpageheader name="myheader">
<table width="100%"><tr>
<td width="60%" style="color:#0000BB; ">
	<span style="font-weight: bold; font-size: 13pt;">Laporan Barang Keluar TB.SINAR ABADI 2</span>
	<br />Alamat<br />Karawang<br /><br />
	<span style="font-family:dejavusanscondensed;">&#9742;</span> 0267 123 567</td>
<td width="40%" style="text-align: right;">Tanggal<br />
	<span style="font-weight: bold; font-size: 11pt;">'.$dari_tanggal.' s/d '.$sampai_tanggal.'</span>
</td>
</tr></table>
</htmlpageheader>

<htmlpagefooter name="myfooter">
<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
Page {PAGENO} of {nb}
</div>
</htmlpagefooter>

<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->

<table class="items" width="100%" style="font-size: 9pt; border-collapse: collapse; " cellpadding="8">
<thead>
<tr>
<td width="5%">No.</td>
<td width="10%">Tanggal</td>
<td width="25%">Nama Pelanggan</td>
<td width="30%">Nama Barang</td>
<td width="10%">Jumlah</td>
<td width="10%">Harga</td>
<td width="10%">Total</td>
</tr>
</thead>
<tbody>
<!-- ITEMS HERE -->
';

$no = 0;
$jumlahStok = 0;
$query="select * from vpenjualan_detail 
			where tanggal_posting BETWEEN '".$dari_tanggal."' and '".$sampai_tanggal."' 
		order by tanggal_posting,nama_barang";
$tbl = mysqli_query($koneksi,$query);
//$html1='';
while($row = mysqli_fetch_array($tbl))
{
    $no = $no+1;
	//$stok = number_format($row["stok"]);
	$jumlahStok = $jumlahStok + $row["jumlah_harga"];

    $html .= '<tr>
                <td align="center">' .$no. '</td>
                <td align="center">' .$row["tanggal_posting"]. '</td>
                <td>' .$row["nama_pelanggan"]. '</td>
                <td>' .$row["nama_barang"]. '</td>
                <td align="right">' .number_format($row["jumlah"]). '</td>
                <td align="right">' .number_format($row["harga"]). '</td>
                <td align="right">' .number_format($row["jumlah_harga"]). '</td>
			 </tr>';	
}

$html .= '<tr>
<td class="blanktotal" colspan="6" rowspan="1" align="right"><b>TOTAL</b></td>
<td class="totals cost"><b>' .number_format($jumlahStok). '</b></td>
</tr>';

$html .='</tbody>
</table>
</body>
</html>
';

//$mpdf = new \Mpdf\Mpdf();

$mpdf = new \Mpdf\Mpdf([
	'margin_left' => 20,
	'margin_right' => 15,
	'margin_top' => 48,
	'margin_bottom' => 25,
	'margin_header' => 10,
	'margin_footer' => 10
]);

//$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Laporan Barang Keluar");
$mpdf->SetAuthor("Yosep");
$mpdf->SetWatermarkText("Laporan Barang Keluar");
$mpdf->showWatermarkText = true;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');

$mpdf->WriteHTML($html);
$mpdf->Output('LaporanBarangKeluar.pdf', I);

?>