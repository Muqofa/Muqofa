<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");

$dari_tanggal = $_POST['dari_tanggal'];
$sampai_tanggal = $_POST['sampai_tanggal'];
echo "<script type=\"text/javascript\">
        window.open('../../laporan/cetakBarangMasuk.php?dari_tanggal=$dari_tanggal&sampai_tanggal=$sampai_tanggal', '_blank')
        history.back();
      </script>";

//header("location:../../laporan/barang_masuk.php?dari_tanggal=$dari_tanggal&sampai_tanggal=$sampai_tanggal");

?>