<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Barang Masuk
        <small>Laporan</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Laporan</a></li>
        <li class="active">Barang Masuk</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-md-6">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Pilih Tanggal</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
                <button type="button" class="btn btn-primary btn-sm daterange pull-right" data-toggle="tooltip">
                  <i class="fa fa-calendar"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="barang_masuk/input_aksi.php" method="post">
              <div class="box-body">
                <!-- Date dd/mm/yyyy -->
              <div class="form-group">
                <label>Dari Tanggal :</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input name="dari_tanggal" type="text" class="form-control" 
                    data-inputmask="'alias': 'yyyy-mm-dd'" data-mask>
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->              
                <!-- Date dd/mm/yyyy -->
                <div class="form-group">
                <label>Sampai Tanggal :</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input name="sampai_tanggal" type="text" class="form-control" 
                    data-inputmask="'alias': 'yyyy-mm-dd'" data-mask>
                </div>
              </div>
              <!-- /.form group -->
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Print Preview</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->

        <div class="col-md-8">
          
        </div>  
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->