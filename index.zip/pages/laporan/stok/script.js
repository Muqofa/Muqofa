$(function () {
  $('#example').DataTable( {
    //dom: 'Bfrtip',
    //    buttons: [
    //        {
    //            text: 'Preview',
    //            action: function ( e, dt, node, config ) {
    //                window.open('../laporan/cetakStok.php', '_blank');
    //                //alert( 'Menuju form tambah' );
    //            }
    //        }
            
    //    ]
    } );

  });