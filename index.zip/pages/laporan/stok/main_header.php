<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Stok
        <small>Laporan</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Laporan</a></li>
        <li class="active">Stok</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Stok</h3>
              <div class="box-tools">
                <?php
                    echo "<a href='../../pages/laporan/cetakStok.php' target='_blank' class='btn btn-default'>
                           <i class='fa fa-print'></i> Print</a>
                    
                    ";
                ?>          
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama Barang</th>
                  <th>Stok</th>
                  <th>Harga Jual</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    $tbl = mysqli_query($koneksi,"select * from vstok");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        echo "<tr>
                        <td>
                            ".$row['kode_barang']."
                        </td>
                        <td>".$row['nama_barang']."</td>
                        <td>".number_format($row['stok'])."</td>
                        <td>".number_format($row['harga_jual'])."</td>
                        <td>
                            
                        </td>
                    </tr>";
                    }
                ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->