<?php

require_once __DIR__ . '../../../plugins/mpdf/vendor/autoload.php';
include '../layout/functions.php';
$html = '

<html>
<head>
<style>
body {font-family: sans-serif;
	font-size: 10pt;
}
p {	margin: 0pt; }
table.items {
	border: 0.1mm solid #000000;
}
td { vertical-align: top; }
.items td {
	border-left: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
table thead td { background-color: #EEEEEE;
	text-align: center;
	border: 0.1mm solid #000000;
	font-variant: small-caps;
}
.items td.blanktotal {
	background-color: #EEEEEE;
	border: 0.1mm solid #000000;
	background-color: #FFFFFF;
	border: 0mm none #000000;
	border-top: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
.items td.totals {
	text-align: right;
	border: 0.1mm solid #000000;
}
.items td.cost {
	text-align: "." center;
}
</style>
</head>
<body>

<!--mpdf
<htmlpageheader name="myheader">
<table width="100%"><tr>
<td width="50%" style="color:#0000BB; ">
	<span style="font-weight: bold; font-size: 14pt;">Laporan Stok TB.SINAR ABADI 2</span>
	<br />Alamat<br />Karawang<br /><br />
	<span style="font-family:dejavusanscondensed;">&#9742;</span> 0267 123 567</td>
<td width="50%" style="text-align: right;">Tanggal<br />
	<span style="font-weight: bold; font-size: 12pt;">'.date("Y/m/d h:i:s").'</span>
</td>
</tr></table>
</htmlpageheader>

<htmlpagefooter name="myfooter">
<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
Page {PAGENO} of {nb}
</div>
</htmlpagefooter>

<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->

<table class="items" width="100%" style="font-size: 9pt; border-collapse: collapse; " cellpadding="8">
<thead>
<tr>
<td width="5%">No.</td>
<td width="70%">Nama Barang</td>
<td width="15%">Kode</td>
<td width="10%">Jumlah</td>
</tr>
</thead>
<tbody>
<!-- ITEMS HERE -->
';

$no = 0;
$jumlahStok = 0;
$tbl = mysqli_query($koneksi,"select * from vstok order by nama_barang");
//$html1='';
while($row = mysqli_fetch_array($tbl))
{
    $no = $no+1;
	$stok = number_format($row["stok"]);
	$jumlahStok = $jumlahStok + $row["stok"];

    $html .= '<tr>
                <td align="center">' .$no. '</td>
                <td>' .$row["nama_barang"]. '</td>
                <td align="center">' .$row["kode_barang"]. '</td>
                <td align="right">' .$stok. '</td>
			 </tr>';
	
}

$html .= '<tr>
<td class="blanktotal" colspan="3" rowspan="1" align="right"><b>TOTAL</b></td>
<td class="totals cost"><b>' .number_format($jumlahStok). '</b></td>
</tr>';

$html .='</tbody>
</table>
</body>
</html>
';

//$mpdf = new \Mpdf\Mpdf();

$mpdf = new \Mpdf\Mpdf([
	'margin_left' => 20,
	'margin_right' => 15,
	'margin_top' => 48,
	'margin_bottom' => 25,
	'margin_header' => 10,
	'margin_footer' => 10
]);

//$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Laporan Stok");
$mpdf->SetAuthor("Yosep");
$mpdf->SetWatermarkText("Laporan Stok");
$mpdf->showWatermarkText = true;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');

$mpdf->WriteHTML($html);
$mpdf->Output('LaporanStok.pdf', I);

?>