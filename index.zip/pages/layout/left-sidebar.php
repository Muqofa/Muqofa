<?php
  
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        
        <?php
        function isActive($menu, $mode="full"){
            global $active_menu;
            if ($mode == "partial")
              //echo ($active_menu == $menu? "active": "");
              return ($active_menu == $menu? "active": "");
            else
              ///echo ($active_menu == $menu? "class='active'": "");
              return ($active_menu == $menu? "class='active'": "");
          }
        
        if ($_SESSION['role']=='pengelola') {
           echo "                    
              <li class='treeview'>          
                <a href='../../pages/home/homePengelola.php'>
                <i class='fa fa-dashboard'></i> <span>Home</span>
                    <span class='pull-right-container'>
                     <i class='fa fa-angle-left pull-right'></i>
                    </span>
                </a>
             </li>            
                <li class='treeview'>
                  <a href='#'>
                    <i class='fa fa-laptop'></i> <span>Master</span>
                    <span class='pull-right-container'>
                      <i class='fa fa-angle-left pull-right'></i>
                    </span>
                  </a>
                  <ul class='treeview-menu'>
                    <li ".isActive('user').">
                      <a href='../../pages/master/user.php'><i class='fa fa-circle-o'></i> Data Pengguna </a>
                    </li>
                  </ul>
                </li>
             
             <li class='treeview'>
              <a href='#'>
                <i class='fa fa-laptop'></i> <span>Transaksi</span>
                <span class='pull-right-container'>
                  <i class='fa fa-angle-left pull-right'></i>
                </span>
              </a>
              <ul class='treeview-menu'>
                <li ".isActive('barang_masuk').">
                  <a href='../../pages/transaksi/barang_masuk.php'><i class='fa fa-circle-o'></i> Barang Masuk </a>
                </li>
                <li ".isActive('barang_keluar').">
                  <a href='../../pages/transaksi/barang_keluar.php'><i class='fa fa-circle-o'></i> Barang Keluar </a>
                </li>            
              </ul> 
            </li>

          ";
        }
        
        if ($_SESSION['role']=='pimpinan') {
           echo "
                    
              <li class='treeview'>          
                <a href='../../pages/home/homePimpinan.php'>
                <i class='fa fa-dashboard'></i> <span>Home</span>
                    <span class='pull-right-container'>
                     <i class='fa fa-angle-left pull-right'></i>
                    </span>
                </a>
             </li>
              <li class='treeview'>
              <a href='#'>
                <i class='fa fa-laptop'></i> <span>Laporan</span>
                <span class='pull-right-container'>
                  <i class='fa fa-angle-left pull-right'></i>
                </span>
              </a>
              <ul class='treeview-menu'>
                <li ".isActive('stok_barang').">
                  <a href='../../pages/laporan/stok.php'><i class='fa fa-circle-o'></i> Stok Barang </a>
                </li>
                <li ".isActive('laporan_barang_masuk').">
                  <a href='../../pages/laporan/barang_masuk.php'><i class='fa fa-circle-o'></i> Barang Masuk</a>
                </li>
                <li ".isActive('laporan_barang_keluar').">
                  <a href='../../pages/laporan/barang_keluar.php'><i class='fa fa-circle-o'></i> Barang Keluar</a>
                </li>
              </ul> 
             </li>
            
        <li class='treeview'>
          <a href='#'>
            <i class='fa fa-laptop'></i> <span>Master</span>
            <span class='pull-right-container'>
              <i class='fa fa-angle-left pull-right'></i>
            </span>
          </a>
          <ul class='treeview-menu'>
            <li ".isActive('user').">
              <a href='../../pages/master/user.php'><i class='fa fa-circle-o'></i> Data Pengguna </a>
            </li>
          </ul>
        </li>

            ";
        }
        
        if ($_SESSION['role']=='admin') {
           echo "
                    
              <li class='treeview'>          
                <a href='../../pages/home/homeAdmin.php'>
                <i class='fa fa-dashboard'></i> <span>Home</span>
                    <span class='pull-right-container'>
                     <i class='fa fa-angle-left pull-right'></i>
                    </span>
                </a>
             </li>
             <li class='treeview'>
              <a href='#'>
                <i class='fa fa-laptop'></i> <span>Transaksi</span>
                <span class='pull-right-container'>
                  <i class='fa fa-angle-left pull-right'></i>
                </span>
              </a>
              <ul class='treeview-menu'>
                <li ".isActive('barang_masuk').">
                  <a href='../../pages/transaksi/barang_masuk.php'><i class='fa fa-circle-o'></i> Barang Masuk </a>
                </li>
                <li ".isActive('barang_keluar').">
                  <a href='../../pages/transaksi/barang_keluar.php'><i class='fa fa-circle-o'></i> Barang Keluar </a>
                </li>            
              </ul> 
            </li>
        
        <li class='treeview'>
          <a href='#'>
            <i class='fa fa-laptop'></i> <span>Master</span>
            <span class='pull-right-container'>
              <i class='fa fa-angle-left pull-right'></i>
            </span>
          </a>
          <ul class='treeview-menu'>
            <li ".isActive('data_barang').">
              <a href='../../pages/master/data_barang.php'><i class='fa fa-circle-o'></i> Data Barang </a>
            </li>
            <li ".isActive('pelanggan').">
              <a href='../../pages/master/pelanggan.php'><i class='fa fa-circle-o'></i> Data Pelanggan </a>
            </li>
            <li ".isActive('supplier').">
              <a href='../../pages/master/supplier.php'><i class='fa fa-circle-o'></i> Data Supplier </a>
            </li>
            <li ".isActive('user').">
              <a href='../../pages/master/user.php'><i class='fa fa-circle-o'></i> Data Pengguna </a>
            </li>
          </ul>
        </li>

            ";
        }
        ?>

        

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<script>
  var parent = $("ul.sidebar-menu li.active").closest("ul").closest("li");
  if (parent[0] != undefined)
    $(parent[0]).addClass("active");
</script>