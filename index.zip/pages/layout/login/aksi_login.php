<?php 

include '../../layout/functions.php';

date_default_timezone_set("Asia/Bangkok");
$username = $_POST['username'];
$password = md5($_POST['password']);

$login = mysqli_query($koneksi, "select * from tuser where username='$username' and password='$password'");
$cek = mysqli_num_rows($login);

if($cek > 0){
	session_start();
	while($row = mysqli_fetch_array($login))
    {        
	    $_SESSION['username'] = $row['username'];
	    $_SESSION['nama'] = $row['nama'];
	    $_SESSION['role'] = $row['role'];
	    $_SESSION['userid'] = $row['userid'];		
    }
	$_SESSION['status'] = "login";

	switch ($_SESSION['role']) {
      case "pimpinan":
        header("location:../../home/homePimpinan.php");
        break;
      case "admin":
        header("location:../../home/homeAdmin.php");
        break;
      case "pengelola":
        header("location:../../home/homeAdmin.php");
        break;
      default:
        header("location:../login.php?message=Username atau Password Salah");
    }

}else{
    header("location:../login.php?message=Username atau Password Salah");	        
}


?>