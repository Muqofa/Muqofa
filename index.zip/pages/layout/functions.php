<?php

//Global functions to be used in php files will be listed here

// host web server
$host       =   "localhost";
// username untuk mengakses database
$username   =   "root";
// password untuk mengakses database
$pass       = "";
// database yang digunakan
$database   = "jualan";
// script untuk koneksi ke database
$koneksi = mysqli_connect($host,$username,$pass,$database);

?>