<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2020 <a href="#">TB.SINAR ABADI 2</a>.</strong> All rights
  reserved.
</footer>