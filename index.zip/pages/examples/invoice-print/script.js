$(window).on('load', function(){
	window.print();
});