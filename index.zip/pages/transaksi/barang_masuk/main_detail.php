<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Barang Masuk
        <small>Detail</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transaksi</a></li>
        <li><a href="../transaksi/barang_masuk.php">Barang Masuk</a></li>
        <li class="active">Detail</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-md-4">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="barang_masuk/input_aksi_detail.php" method="post">
              <?php    
                $id = $_GET['id'];            
                echo "<input type='hidden' id='id' name='id' value='$id'>";
              ?>
              
              <div class="box-body">
               
              <div class="form-group">
                  <label>Nama Barang</label>
                  <select class="form-control select2" style="width: 100%;" name="kode_barang">
                    <?php
                        include '../layout/functions.php';
                        $tbl = mysqli_query($koneksi,"select * from tdata_barang");
                        while($row = mysqli_fetch_array($tbl))
                        {
                            echo "<option value=".$row['kode_barang'].">".$row['nama_barang']."</option>";
                        }
                    ?>                  
                  </select>
                </div>
                <div class="form-group">
                  <label for="harga">Harga Beli</label>
                  <input type="number" class="form-control" id="harga" 
                          name="harga" placeholder="0" value="0">
                </div>
                <div class="form-group">
                  <label for="jumlah">Jumlah</label>
                  <input type="number" class="form-control" id="jumlah" 
                          name="jumlah" placeholder="0" value="0">
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
                
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->

        <div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Barang Masuk</h3>
              <div class="box-tools">
                <?php
                    echo "<a href='../../pages/transaksi/cetakPembelian.php?id=$id' target='_blank' class='btn btn-default'>
                           <i class='fa fa-print'></i> Print</a>
                    
                    ";
                ?>          
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th colspan="6">Information</th>
              </tr>
                <tr>
                  <th>Kode</th>
                  <th>Nama Barang</th>
                  <th>Jumlah</th>
                  <th>Harga</th>
                  <th>Total</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    $id = $_GET['id'];

                    $tbl = mysqli_query($koneksi,"select * from vpembelian_detail where id = '$id'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        echo "<tr>
                        <td>
                            ".$row['kode_barang']."
                        </td>
                        <td>".$row['nama_barang']."</td>
                        <td>".number_format($row['jumlah'])."</td>
                        <td>".number_format($row['harga'])."</td>
                        <td>".number_format($row['jumlah_harga'])."</td>
                        <td>
                            <a href='barang_masuk/delete_detail.php?id=$row[id]&kode_barang=$row[kode_barang]'>Delete</a>
                        </td>
                    </tr>";
                    }
                ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->