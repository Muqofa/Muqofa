$(function () {

    $('.daterange').daterangepicker({
        ranges: {
            'Hari Ini': [moment(), moment()],
            'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            '7 Hari Lalu': [moment().subtract(6, 'days'), moment()],
            '30 Hari Lalu': [moment().subtract(29, 'days'), moment()],
            'Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
            'Bulan Lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(1, 'days'),
        endDate: moment()
    }, function (start, end) {
            //window.alert("You chose: " + start.format('YYYY/MM/DD') + ' - ' + end.format('YYYY/MM/DD'));
            window.open("barang_masuk.php?start=" + start.format('YYYY/MM/DD') + "&end=" + end.format('YYYY/MM/DD')+"","self");
    });

  $('#example').DataTable( {
    //dom: 'Bfrtip',
        //buttons: [
        //    {
        //        text: 'Back',
        //        action: function ( e, dt, node, config ) {
        //            window.location = '../dashboard/index.php';
        //            //alert( 'Menuju form tambah' );
        //        }
        //    }
            //,'copy', 'csv', 'excel', 'pdf', 'print'
        //]
    } );
    //Initialize Select2 Elements
    $(".select2").select2();

        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("yyyy/mm/dd", {"placeholder": "yyyy/mm/dd"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();
    
  });