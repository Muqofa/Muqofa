<?php
include '../../layout/functions.php';

$id = $_GET['id'];

mysqli_query($koneksi,"DELETE FROM ttransaksi_header WHERE id='$id'");
 
header("location:../../transaksi/barang_masuk.php");

?>