<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Barang Masuk
        <small>Header</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transaksi</a></li>
        <li class="active">Barang Masuk</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-4">
          <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Tambah</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form role="form" action="barang_masuk/input_aksi.php" method="post">
                <div class="box-body">
                  <!-- Date dd/mm/yyyy -->
                <div class="form-group">
                  <label>Tanggal :</label>

                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <?php
                    echo "<input name='tanggal_posting' type='text' class='form-control' 
                        data-inputmask=''alias': 'yyyy/mm/dd'' data-mask value='".date('Y/m/d')."'>"
                    ?> 
                  </div>
                  <!-- /.input group -->
                </div>
                <!-- /.form group -->

                <!-- Date mm/dd/yyyy -->
                  <div class="form-group">
                    <label>Supplier</label>
                    <select class="form-control select2" style="width: 100%;" name="kode_supplier">
                      <?php
                          include '../layout/functions.php';
                          $tbl = mysqli_query($koneksi,"select * from tsupplier");
                          while($row = mysqli_fetch_array($tbl))
                          {
                              echo "<option value=".$row['kode_supplier'].">".$row['nama_supplier']."</option>";
                          }
                      ?>                  
                    </select>
                  </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
              </form>
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
        <div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Barang Masuk</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
                <button type="button" class="btn btn-primary btn-sm daterange pull-right" data-toggle="tooltip">
                  <i class="fa fa-calendar"></i></button>
              </div>

            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>Supplier</th>
                  <th>Alamat</th>
                  <th>Telp</th>
                  <th>Tanggal Update</th>
                  <th>Kode User</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    if(isset($_GET['start'])){    
                        $start = $_GET['start'];
					}
                    else {                    
                        $start = date("Y/m/d");
                    }
                    if(isset($_GET['end'])){     
                        $end = $_GET['end'];
					}
                    else {                   
                        $end = date("Y/m/d");
                    }
                    $tbl = mysqli_query($koneksi,"select * from vpembelian_header where tanggal_posting between '$start' AND '$end'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        echo "<tr>
                        <td>
                            ".$row['tanggal_posting']."
                            <a href='../transaksi/barang_masuk_detail.php?id=$row[id]'>Detail</a>
                        </td>
                        <td>".$row['nama_supplier']."</td>
                        <td>".$row['alamat']."</td>
                        <td>".$row['telp']."</td>
                        <td>".$row['tanggal_update']."</td>
                        <td>".$row['update_by']."</td>
                        <td>
                            <a href='barang_masuk/delete.php?id=$row[id]'>Delete</a>
                        </td>
                    </tr>";
                    }
                ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->