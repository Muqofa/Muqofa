<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");

$id = $_POST['id'];
$kode_barang   = $_POST['kode_barang'];
$harga   = $_POST['harga'];
$jumlah = $_POST['jumlah'];
session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

IF ($jumlah >= 0 && $harga > 500){
    mysqli_query($koneksi,"DELETE FROM ttransaksi_detail WHERE id='$id' and kode_barang='$kode_barang'");
    mysqli_query($koneksi,"INSERT INTO ttransaksi_detail (id, kode_barang, jumlah, harga)
                                        VALUES('$id','$kode_barang','$jumlah','$harga')");
    mysqli_query($koneksi,"UPDATE tdata_barang SET harga_beli = '$harga', tanggal_update='$update_by' 
                            , update_by = '$update_by'
                            WHERE kode_barang = '$kode_barang'
                            ");    
}
 
header("location:../../transaksi/barang_masuk_detail.php?id=$id");

?>