<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");
//$id              = $_POST['id'];
$kode_transaksi  = 1;//$_POST['kode_transaksi'];
$kode_supplier   = $_POST['kode_supplier'];
$tanggal_posting = $_POST['tanggal_posting'];

session_start();
$update_by = $_SESSION['userid'];
$update_date = date("Y-m-d h:i:s");

mysqli_query($koneksi,"INSERT INTO ttransaksi_header (id, kode_transaksi, kode_supplier, 
                                    tanggal_posting, tanggal_update, update_by)
 VALUES(0,'$kode_transaksi','$kode_supplier','$tanggal_posting'
         ,'$update_date','$update_by')");

$tbl = mysqli_query($koneksi,"select * from ttransaksi_header 
                                where kode_supplier = '$kode_supplier'
                                and tanggal_update = '$update_date'
                                order by id desc");
$id = 0;
while($row = mysqli_fetch_array($tbl))
{
   $id = $row['id'];
	break 1;
}
                        
header("location:../../transaksi/barang_masuk_detail.php?id=$id");


?>