<?php

require_once __DIR__ . '../../../plugins/mpdf/vendor/autoload.php';
include '../layout/functions.php';
$id = $_GET['id'];
$no = 0;
$jumlahHarga = 0;
$query="select * from vpembelian_detail where id = '".$id."'
		order by nama_barang";
$tbl = mysqli_query($koneksi,$query);
$tanggal = '';
$nama_supplier = '';
$alamat = '';
$telp = '';
//$diskon = 0;
//$dibayarkan = 0;
while($row = mysqli_fetch_array($tbl))
{
	$tanggal = $row["tanggal_posting"];
	$nama_supplier = $row["nama_supplier"];
	$alamat = $row["alamat"];
	$telp = $row["telp"];
	//$diskon = $row["diskon"];
	//$dibayarkan = $row["dibayarkan"];

	break 1;
}

mysqli_data_seek($tbl, 0);

$html = '

<html>
<head>
<style>
body {font-family: sans-serif;
	font-size: 10pt;
}
p {	margin: 0pt; }
table.items {
	border: 0.1mm solid #000000;
}
td { vertical-align: top; }
.items td {
	border-left: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
table thead td { background-color: #EEEEEE;
	text-align: center;
	border: 0.1mm solid #000000;
	font-variant: small-caps;
}
.items td.blanktotal {
	background-color: #EEEEEE;
	border: 0.1mm solid #000000;
	background-color: #FFFFFF;
	border: 0mm none #000000;
	border-top: 0.1mm solid #000000;
	border-right: 0.1mm solid #000000;
}
.items td.totals {
	text-align: right;
	border: 0.1mm solid #000000;
}
.items td.cost {
	text-align: "." center;
}
</style>
</head>
<body>

<!--mpdf
<htmlpageheader name="myheader">
<table width="100%"><tr>
<td width="60%" style="color:#0000BB; ">
	<span style="font-weight: thin; font-size: 9pt;">Pembelian Barang TB.SINAR ABADI 2
		<br />Alamat : Karawang			
		<span style="font-family:dejavusanscondensed;">&#9742;</span>
	</span>	
</td>

<td width="40%" style="text-align: right;font-size: 9pt;">Tanggal<br />
	<span style="font-weight: thin;">'.$tanggal.'</span>
</td>
</tr></table>
</htmlpageheader>

<htmlpagefooter name="myfooter">
<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
Page {PAGENO} of {nb}
</div>
</htmlpagefooter>

<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->

<table width="100%" style="font-family: serif;" cellpadding="10">
<tr>
<td width="50%" style="border: 0.1mm solid #888888; ">
	<span style="font-size: 7pt; color: #555555; font-family: sans;">Supplier :</span>
	<br>
	 ';
$html .= '<span style="font-size: 9pt; color: #555555; font-family: sans;">' .$nama_supplier. ' </span>
</td>
<td width="50%" style="border: 0.1mm solid #888888;">
	<span style="font-size: 7pt; color: #555555; font-family: sans;">Alamat :</span>
	<br>';
$html .= '<span style="font-size: 7pt; color: #555555; font-family: sans;">' .$alamat.' telp ' .$telp.' </span>
</td>
</tr>
</table>

<table class="items" width="100%" style="font-size: 9pt; border-collapse: collapse; " cellpadding="8">
<thead>
<tr>
<td width="5%">No</td>
<td width="35%">Nama Barang</td>
<td width="5%">Jumlah</td>
<td width="10%">Harga</td>
<td width="10%">Total</td>
</tr>
</thead>
<tbody>
<!-- ITEMS HERE -->
';

//$html1='';
while($row = mysqli_fetch_array($tbl))
{
    $no = $no+1;
	//$stok = number_format($row["stok"]);
	$jumlahHarga = $jumlahHarga + $row["jumlah_harga"];

    $html .= '<tr>
                <td align="center">' .$no. '</td>
                <td>' .$row["nama_barang"]. '</td>
                <td align="right">' .number_format($row["jumlah"]). '</td>
                <td align="right">' .number_format($row["harga"]). '</td>
                <td align="right">' .number_format($row["jumlah_harga"]). '</td>
			 </tr>';	
}

$html .= '<tr>
<td class="blanktotal" colspan="4" rowspan="1" align="right">Total Harga</td>
<td class="totals cost">' .number_format($jumlahHarga). '</td>
</tr>';

$html .='</tbody>
</table>
</body>
</html>
';

//$mpdf = new \Mpdf\Mpdf();

$mpdf = new \Mpdf\Mpdf([
	'margin_left' => 20,
	'margin_right' => 15,
	'margin_top' => 15,
	'margin_bottom' => 25,
	'margin_header' => 5,
	'margin_footer' => 10
]);

//$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Pembelian Barang");
$mpdf->SetAuthor("Yosep");
$mpdf->SetWatermarkText("TB.SINAR ABADI 2");
$mpdf->showWatermarkText = true;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');

$mpdf->WriteHTML($html);
$mpdf->Output('PembelianBarang.pdf', I);

?>