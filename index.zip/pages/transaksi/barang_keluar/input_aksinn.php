<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");
//$id              = $_POST['id'];
$kode_transaksi  = 2;//$_POST['kode_transaksi'];
$kode_pelanggan   = $_POST['kode_pelanggan'];
$tanggal_posting = $_POST['tanggal_posting'];

$dateTimestamp1 = strtotime($tanggal_posting); 
$dateTimestamp2 = strtotime(date("Y/m/d")); 

session_start();
echo ''.$tanggal_posting.''.date("Y/m/d"). '';
if ($dateTimestamp1 < $dateTimestamp1) {
    header("location:../../transaksi/barang_keluar.php");
    return;
}

?>