$(function () {
  $('#example').DataTable( {
    dom: 'Bfrtip',
        buttons: [
            {
                text: 'Back',
                action: function ( e, dt, node, config ) {
                    window.location = '../transaksi/barang_keluar.php';
                    //alert( 'Menuju form tambah' );
                }
            }
            ,'excel', 'pdf'
        ]
    } );
    //Initialize Select2 Elements
    $(".select2").select2();

        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("yyyy/mm/dd", {"placeholder": "yyyy/mm/dd"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();
    
});
