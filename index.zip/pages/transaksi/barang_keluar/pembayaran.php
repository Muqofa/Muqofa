<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");

$id = $_POST['id'];
$diskon   = $_POST['diskon'];
$dibayarkan = $_POST['bayar'];

IF ($dibayarkan > 0){
    mysqli_query($koneksi,"UPDATE ttransaksi_header set diskon = '$diskon', dibayarkan = '$dibayarkan'
                           , status_transaksi = '1' WHERE id='$id'");   
                           
    header("location:../../transaksi/cetakKwitansi.php?id=$id");
}
else {
	header("location:../../transaksi/barang_keluar_detail.php?id=$id");
}




?>