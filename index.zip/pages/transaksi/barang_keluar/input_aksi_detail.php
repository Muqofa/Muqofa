<?php 
include '../../layout/functions.php';
date_default_timezone_set("Asia/Bangkok");

$id = $_POST['id'];
$kode_barang   = $_POST['kode_barang'];
$jumlah = $_POST['jumlah'];

$result = mysqli_query($koneksi,"SELECT stok,harga_jual,harga_beli FROM vstok WHERE kode_barang='$kode_barang'"); 
$row = mysqli_fetch_assoc($result); 
$sum = $row['stok'];   
$harga = $row['harga_jual'];   
$harga_beli = $row['harga_beli'];

IF ($sum-$jumlah >= 0 && $jumlah > 0){
    mysqli_query($koneksi,"DELETE FROM ttransaksi_detail WHERE id='$id' and kode_barang='$kode_barang'");
    mysqli_query($koneksi,"INSERT INTO ttransaksi_detail (id, kode_barang, jumlah, harga, harga_beli)
     VALUES('$id','$kode_barang','$jumlah','$harga','$harga_beli')");
}

header("location:../../transaksi/barang_keluar_detail.php?id=$id");

?>