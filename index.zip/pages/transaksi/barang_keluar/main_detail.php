<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Barang Keluar
        <small>Detail</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transaksi</a></li>
        <li><a href="../transaksi/barang_keluar.php">Barang Keluar</a></li>
        <li class="active">Detail</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-md-4">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="barang_keluar/input_aksi_detail.php" method="post">
              <?php    
                $id = $_GET['id'];            
                echo "<input type='hidden' id='id' name='id' value='$id'>";
              ?>
              
              <div class="box-body">
               
              <div class="form-group">
                  <label>Nama Barang</label>
                  <select class="form-control select2" style="width: 100%;" name="kode_barang">
                    <?php
                        include '../layout/functions.php';
                        $tbl = mysqli_query($koneksi,"select * from vstok where stok > 0");
                        while($row = mysqli_fetch_array($tbl))
                        {
                            echo "<option value=".$row['kode_barang'].">".$row['nama_barang']." [".$row['stok']."]</option>";
                        }
                    ?>                  
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="jumlah">Jumlah</label>
                  <input type="number" class="form-control" id="jumlah" 
                          name="jumlah" placeholder="1" value="1">
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Tambah</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->

        <div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Barang Keluar</h3>
              <div class="box-tools">
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form role="form" action="barang_keluar/pembayaran.php" method="post">
              <?php    
                $id = $_GET['id'];            
                echo "<input type='hidden' name='id' value='$id'>";
              ?>
              
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width='30px'>Kode</th>
                  <th>Nama Barang</th>
                  <th align='right' width='50px'>Jumlah</th>
                  <th align='right'>Harga</th>
                  <th align='right'>Sub Total</th>
                  <th width='70px'>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    include '../layout/functions.php';
                    $id = $_GET['id'];
                    $total = 0;
                    $diskon = 0;
                    $dibayarkan = 0;
                    $status_transaksi=0;
                    $tbl = mysqli_query($koneksi,"select * from vpenjualan_detail where id = '$id'");
                    while($row = mysqli_fetch_array($tbl))
                    {
                        $total = $total+$row['jumlah_harga'];
                        $diskon = $row['diskon'];
                        $dibayarkan = $row['dibayarkan'];
                        $status_transaksi = $row['status_transaksi'];
                        echo "<tr>
                        <td>
                            ".$row['kode_barang']."
                        </td>
                        <td>".$row['nama_barang']."</td>
                        <td align='right'>".number_format($row['jumlah'])."</td>
                        <td align='right'>".number_format($row['harga'])."</td>
                        <td align='right'>".number_format($row['jumlah_harga'])."</td>
                        <td>
                            <a href='barang_keluar/delete_detail.php?id=$row[id]&kode_barang=$row[kode_barang]'>Delete</a>
                        </td>
                    </tr>";
                    }
                    echo "<tr>
                        <td colspan='4' align='right'>
                            Total Harga
                        </td>
                        <td align='right'>".number_format($total)."</td>
                        <td></td>
                    </tr>";
                    echo "<tr>
                        <td colspan='3' align='right'>Diskon (%)</td>
                        <td colspan='1' align='left' width='70px'>
                            <input type='number' class='form-control input-discount' id='diskon' 
                                        name='diskon' placeholder='0' value='$diskon' ng-model='diskon' max='100' ng-init='diskon=$diskon'>
                        </td>
                        <td colspan='1' align='right'>{{diskon/100*".$total." | number:0}}</td>    
                        <td></td>
                    </tr>";
                    echo "<tr>
                        <td colspan='4' align='right'>
                            Total Harga - Diskon
                        </td>
                        <td align='right'>{{".$total."-diskon/100*".$total." | number:0}}</td>
                        <td></td>
                    </tr>";
                    echo "<tr>
                        <td colspan='4' align='right'>
                            Dibayarkan
                        </td>
                        <td colspan='1' align='left' width='100px'>
                            <input type='number' class='form-control input-bayar'
                                        name='bayar' placeholder='0' value='$dibayarkan' 
                                        ng-model='bayar' ng-init='bayar=$dibayarkan'>
                        </td>
                        <td>                            
                            <button type='submit' class='btn btn-primary'>Bayar</button>
                        </td>
                    </tr>";
                    echo "<tr>
                        <td colspan='4' align='right'>
                            Kembali
                        </td>
                        <td align='right'>{{bayar-(".$total."-diskon/100*".$total.") | number:0}}</td>
                        ";
                    if($status_transaksi==1){
                        echo "<td>
                                    <a href='cetakKwitansi.php?id=".$id."' target='_blank' class='btn btn-default'>
                                        <i class='fa fa-print'></i> Print</a>
                              </td>";
					}else{
                        "<td></td>";
					}
                    echo "
                    </tr>";
                ?>

                </tbody>
              </table>
              </form>   
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>  
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->