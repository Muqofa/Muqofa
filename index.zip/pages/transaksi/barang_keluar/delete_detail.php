<?php
include '../../layout/functions.php';

$id = $_GET['id'];
$kode_barang = $_GET['kode_barang'];

mysqli_query($koneksi,"DELETE FROM ttransaksi_detail WHERE id='$id' and kode_barang='$kode_barang'");
 
header("location:../../transaksi/barang_keluar_detail.php?id=$id");

?>